<?php

/**
* Classe para execucao de Queries
*
* @author    Daniel Triboni
* @copyright (c) 2017 - Escort - All Rights Reserved
*/
class queries extends mysqlconn {
		
	private $sqlQuery;
	
	private $sqlQueryCompl;
	
	private $sqlQueryInner;
	
	private $sqlQueryGroup;
	
	private $retRecords;
	
	private $retHTML;
	
	
	/**
	* Class Constructor
	*
	* @author    Daniel Triboni
	* @return    resource
	*/
	public function __construct() {	
		parent::__construct();
	}
	
    
	/**
	 * Query Notification Nav Menu 
	 * @return array
	 */
	public function fQueryNotificationNavMenu(){
	
		$this->sqlQuery = "SELECT
								CONCAT('Seu Perfil ', p.apelido) as titulo,
								'dashboard' as url,
								CASE WHEN (p.aprovado = 1) THEN
						    		'foi aprovado com Sucesso!'
						    	WHEN (p.aprovado = 2) THEN
						    		'<strong>foi reprovado!</strong>'						    	
						    	END AS aprovado
							FROM pessoas p
							WHERE p.lido = 0
							AND p.pesid = {$_SESSION['sPersonID']}
							AND p.aprovado > 0	
						UNION 
							SELECT
								CONCAT('Seu An&uacute;ncio ', ap.titulo) as titulo,
								CONCAT('person/', p.url, '/', ap.url) as url,
								CASE WHEN (ap.aprovado = 1) THEN
						    		'foi publicado com Sucesso!'
						    	WHEN (ap.aprovado = 2) THEN
						    		'<strong>foi reprovado!</strong>'						    	
						    	END AS aprovado
							FROM anuncios_pessoas ap
							INNER JOIN pessoas p ON p.pesid = ap.pesid
							WHERE ap.lido = 0
							AND ap.pesid = {$_SESSION['sPersonID']}
							AND ap.aprovado > 0";
		
		$this->fExecuteSql($this->sqlQuery);
		$this->retRecords = $this->fShowRecords();
		return $this->retRecords;
	}
	
	
	/**
	 * Query Plans in Payment Page
	 * @return array
	 */
	public function fQueryPlans($type = 1, $plaid = null){
		$this->sqlQueryCompl = ($plaid != null ? " AND pl.plaid = {$plaid}" : "");
		$this->sqlQuery = "SELECT
								pl.*
							FROM planos pl
							WHERE pl.ativo = 1
							AND pl.tipo = {$type}
							{$this->sqlQueryCompl}
							ORDER BY pl.plaid ASC";
		$this->fExecuteSql($this->sqlQuery);
		$this->retRecords = $this->fShowRecords();
		return $this->retRecords;
	}
	
	
	/**
	 * Query Notification Counters in Home Page
	 * @return array
	 */
	public function fQueryNotificationCounters(){
	
		$this->sqlQuery = "SELECT 
							(SELECT COUNT(1) FROM pessoas p WHERE p.ativo = 1 AND p.aprovado = 1) AS pc,
							(SELECT COUNT(1) FROM pessoas p WHERE p.logon = 1) AS mo,
							(SELECT COUNT(1) FROM pessoas p WHERE p.ppv = 1 AND p.ppv_online = 1) AS pr,
							(SELECT COUNT(1) FROM anuncios_pessoas ap WHERE ap.ativo = 1 AND ap.aprovado = 1) AS ac";	
		$this->fExecuteSql($this->sqlQuery);
		$this->retRecords = $this->fShowRecords();
		return $this->retRecords;
	}
	
	
	/**
	 * 
	 * @return Resource#ID
	 */
	public function fQueryNotifications2Read() {
		$this->sqlQuery = "UPDATE anuncios_pessoas SET lido = 1 WHERE pesid = ".$_SESSION['sPersonID'];
		$this->fExecuteSql($this->sqlQuery);		
		$this->sqlQuery = "UPDATE pessoas SET lido = 1 WHERE pesid = ".$_SESSION['sPersonID'];
		return $this->fExecuteSql($this->sqlQuery);
	}
	
	
    /**
	* Save New Person Register
	*	
	* @author    Daniel Triboni
	* @param	 object $_REQUEST 
	* @return	 boolean
	*/
	public function fSaveNewPerson($obj, $files){
		
		$this->sqlQuery = "INSERT INTO pessoas (nome, apelido, url, email, senha, 
												 sexo, genero, etnia, 
												 olhos, cabelos, peso, altura, 
												 busto, cintura, quadril, pcm,
												 whatsapp, tel1, tel2,
												 facebook, twitter, googleplus, 
												 rg, cpf, nascimento, naturalidade,
												 documento, comprovacao, dtultimoacesso)
										 VALUES ('".$obj['nome']."', '".$obj['apelido']."', '".$obj['url']."', '".$obj['email']."', '".md5($obj['senha'])."', 
										 	     '".$obj['sexo']."', '".$obj['genero']."', '".$obj['etnia']."', 
										 	     '".$obj['olhos']."', '".$obj['cabelos']."', '".$obj['peso']."', '".$obj['altura']."',  
										 		 '".$obj['busto']."', '".$obj['cintura']."', '".$obj['quadril']."', '".$obj['pcm']."', 
										 		 '".$obj['whatsapp']."', '".$obj['tel1']."', '".$obj['tel2']."',
										 		 '".$obj['facebook']."', '".$obj['twitter']."', '".$obj['googleplus']."',
										 		 '".$obj['rg']."', '".$obj['cpf']."', '".$obj['nascimento']."', '".$obj['naturalidade']."',
										 		 '".$files['documento']."', '".$files['comprovacao']."', now())";
		
		return $this->fExecuteSql($this->sqlQuery);		 
	}
	
	
	/**
	 * Update Person Register
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	public function fUpdateCurrentPerson($obj){
		
		$this->sqlQuery = "UPDATE pessoas SET   
									nome = '".$obj['nome']."', 												  
									senha = '".md5($obj['senha'])."',
									sexo = '".$obj['sexo']."', 
									genero = '".$obj['genero']."', 
									etnia = '".$obj['etnia']."',
									olhos = '".$obj['olhos']."', 
									cabelos = '".$obj['cabelos']."', 
									peso = '".$obj['peso']."', 
									altura = '".$obj['altura']."',
									busto = '".$obj['busto']."', 
									cintura = '".$obj['cintura']."', 
									quadril = '".$obj['quadril']."', 
									pcm = '".$obj['pcm']."',
									whatsapp = '".$obj['whatsapp']."', 
									tel1 = '".$obj['tel1']."', 
									tel2 = '".$obj['tel2']."',
									facebook = '".$obj['facebook']."', 
									twitter = '".$obj['twitter']."', 
									googleplus = '".$obj['googleplus']."',												
									nascimento = '".$obj['nascimento']."', 
									naturalidade = '".$obj['naturalidade']."'
							WHERE pesid = ".$_SESSION['sPersonID'];
		
		return $this->fExecuteSql($this->sqlQuery);									
	}
	
	
	/**
	 * Save Chat Conversations
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	public function fSaveChat($msg, $room){
	
		$this->sqlQuery = "INSERT INTO chats (pesid, lido, jsonmessage) VALUES ({$room}, 0, '".$msg."')";	
		
		$this->fExecuteSql($this->sqlQuery);
		
		return true;
	}
	
	
	/**
	 * Save New Person Ad
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	public function fSaveNewAd($obj){
	
		$this->sqlQuery = "INSERT INTO anuncios_pessoas (titulo, descricao, ativo, url, 
														 pessoasatendimento, idiomas, 
														 moeda, locaisatendimento, pesid)
							VALUES ('".$obj['titulo']."', '".$obj['descricao']."', 1, '".$obj['url']."',
									'".join(", ", $obj['pessoasatendimento'])."', '".join(", ", $obj['idiomas'])."', 
									'".$obj['moeda']."', '".$obj['locaisatendimento']."', {$_SESSION['sPersonID']})";
	
		if($this->fExecuteSql($this->sqlQuery))
		{
			$obj['apid'] = $this->fGetLastInsertID();
			
			if($this->fAdModalities($obj))
			{
				return $this->fAdCaches($obj);
			}else{
					
				return false;
			}
				
		}else{
				
			return false;
		}
	}
	
	
	/**
	 * Save New Person Ad
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	public function fQuerySavePersonPlan($obj){
	
		$this->sqlQuery = "INSERT INTO planos_pessoas (plaid, pesid)
							VALUES (".$obj['plaid'].", {$_SESSION['sPersonID']})";
	
		if($this->fExecuteSql($this->sqlQuery))
		{
			$obj['ppid'] = $this->fGetLastInsertID();
				
			if($this->fQueryPaymentPlans($obj))
			{
				return true;
			}else{
					
				return false;
			}
	
		}else{
	
			return false;
		}
	}
	
	
	/**
	 * Payment Plans of Person
	 * @param object $obj
	 */
	private function fQueryPaymentPlans($obj){
		
		$this->sqlQuery = "INSERT INTO planos_pagamentos (ppid, psid, vloriginal, vencimento)
							VALUES (".$obj['ppid'].", '".$obj['psid']."', ".$obj['vloriginal'].", '".$obj['vencimento']."')";
		
		if($this->fExecuteSql($this->sqlQuery))
		{
			return true;
			
		}else{
			return false;
		}
	}
	
	
	
	public function getAcquiredPlans($psid) {
		
	}
	
	
	/**
	 * Update Person Ad
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	public function fUpdateAd($obj){
	
		$this->sqlQuery = "UPDATE anuncios_pessoas SET
									titulo = '".$obj['titulo']."',
									descricao = '".$obj['descricao']."',
									ativo = ".(is_null($obj['ativo']) ? 0 : 1).",
									url = '".$obj['url']."',
									pessoasatendimento = '".join(", ", $obj['pessoasatendimento'])."',
									idiomas = '".join(", ", $obj['idiomas'])."',
									moeda = '".$obj['moeda']."',
									locaisatendimento = '".$obj['locaisatendimento']."'
							WHERE apid = ".$obj['apid'];
	
		if($this->fExecuteSql($this->sqlQuery))
		{
			if($this->fAdModalities($obj))
			{
				return $this->fAdCaches($obj);
			}else{
			
				return false;
			}
			
		}else{
			
			return false;
		}
	}
	
	
	/**
	 * Remove Person Ad
	 *
	 * @author    Daniel Triboni
	 * @param	 integer $apid
	 * @return	 boolean
	 */
	public function fRemoveAd($apid){
		$this->sqlQuery = "DELETE FROM destaque_pessoas WHERE apid = ".$apid;
		if($this->fExecuteSql($this->sqlQuery))
		{
			$this->sqlQuery = "DELETE FROM pessoas_fotos WHERE apid = ".$apid;
			if($this->fExecuteSql($this->sqlQuery))
			{
				$this->sqlQuery = "DELETE FROM pessoas_cache WHERE apid = ".$apid;
				if($this->fExecuteSql($this->sqlQuery))
				{
					$this->sqlQuery = "DELETE FROM modalidades_pessoas WHERE apid = ".$apid;
					if($this->fExecuteSql($this->sqlQuery))
					{
						$this->sqlQuery = "DELETE FROM anuncios_pessoas WHERE apid = ".$apid;
						return $this->fExecuteSql($this->sqlQuery);
							
					}else{
							
						return false;
					}
						
				}else{
			
					return false;
				}
					
			}else{
					
				return false;
			}
			
		}else{
			
			return false;			
		}		
	}
	
	
	/**
	 * Save Ad Modalities
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	private function fAdModalities($obj){
	
		$this->sqlQuery = "DELETE FROM modalidades_pessoas WHERE apid = ".$obj['apid'];	
		if($this->fExecuteSql($this->sqlQuery))
		{
				
			$this->sqlQueryCompl = "INSERT INTO modalidades_pessoas (modid, apid, ativo) VALUES ";
			foreach ($obj['modalidades'] as $modid)
			{
				$this->sqlQueryCompl .= "({$modid}, {$obj['apid']}, 1), ";				
			}
			
			return $this->fExecuteSql(substr($this->sqlQueryCompl, 0, strlen($this->sqlQueryCompl)-2));
			
		}else{
			
			return false;
		}
	}
	
	
	/**
	 * Save Ad Caches
	 *
	 * @author    Daniel Triboni
	 * @param	 object $_REQUEST
	 * @return	 boolean
	 */
	private function fAdCaches($obj){
	
		$this->sqlQuery = "DELETE FROM pessoas_cache WHERE apid = ".$obj['apid'];
		if($this->fExecuteSql($this->sqlQuery))
		{
			$this->sqlQueryCompl = "INSERT INTO pessoas_cache (apid, c30, c1, c2, 
																c4, c8, c12, viagem)
									VALUES ('{$obj['apid']}', '{$obj['c30']}', '{$obj['c1']}', '{$obj['c2']}', 
											'{$obj['c4']}', '{$obj['c8']}', '{$obj['c12']}', '{$obj['viagem']}') ";
			return $this->fExecuteSql($this->sqlQueryCompl);
				
		}else{
				
			return false;
		}
	}
    
	
    /**
	* Query SQL Errors
	*	
	* @author    Daniel Triboni
	* @return	 array
	*/
    private function fQueryErrorsSaved(){
    	$sql = "SELECT
    				e.id,
    				DATE_FORMAT(e.err_data, '%d/%m/%Y') AS data_erro,
    				DATE_FORMAT(e.err_data, '%H:%i') AS hora_erro,
    				e.err_banco,
    				e.err_erro
    			FROM tblerros e
    			WHERE e.err_enviadoalerta = 'N'
    			ORDER BY e.err_data ASC";
    	$this->fExecuteSql($sql);
    	$ret = $this->fShowRecords();
    	return $ret;
    }
    
    
    /**
	* Update Errors Sent via Email
	*	
	* @author    Daniel Triboni
	* @param	 integer ID
	* @return	 boolean
	*/
    private function fUpdateQueryErrorsSent($id){
    	$sql = "UPDATE tblerros SET err_enviadoalerta = 'S' WHERE id = ".$id;
    	$this->fExecuteSql($sql);
    	return true;	
    }
       
    
    /**
     * Query Featured Models in Home Page
     * @param unknown $gender
     * @param unknown $feature
     * @param unknown $limit
     */
    public function fQueryFeaturedModels($gender, $feature, $limit){
    	$this->sqlQueryCompl = (!empty($gender) ? "AND p.sexo = '{$gender}'" : "");
    	$this->sqlQuery = "SELECT		    				
		    				p.apelido,
		    				p.url AS person,
		    				ap.url AS ad,
		    				pf.imagemurl,
		    				pf.descricao AS descricao_foto,
		    				ap.descricao AS descricao_pessoa,
		    				NULL AS localizacao
		    			FROM destaque_pessoas dp
		    			INNER JOIN anuncios_pessoas ap ON ap.apid = dp.apid
		    			INNER JOIN pessoas_fotos pf ON pf.apid = ap.apid
		    			INNER JOIN pessoas p ON p.pesid = ap.pesid
		    			WHERE ap.ativo = 1
		    			AND ap.aprovado = 1 
		    			AND p.aprovado = 1 
		    			AND p.ativo = 1
		    			{$this->sqlQueryCompl}
		    			AND pf.ativo = 1 
    					AND pf.principal = 'S'
    					AND pf.local = 1
    					AND pf.tipo = 1
		    			AND dp.destaque = {$feature}    					
		    			AND NOW() BETWEEN dp.inicio AND dp.final
		    			GROUP BY p.url
		    			ORDER BY rand() LIMIT {$limit}";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Query Gallery Models
     * @param unknown $gender
     */
    public function fQueryGalleryModels($gender){
    	$this->sqlQueryCompl = (!empty($gender) ? "AND p.sexo = '{$gender}'" : "");
    	$this->sqlQuery = "SELECT
    							ap.url AS ad,
    							p.url AS person,
						    	p.apelido,
						    	p.genero,						    	
    							ap.pessoasatendimento,    						
    						IFNULL((SELECT pf.imagemurl AS thumb 
							     FROM pessoas_fotos pf 
							     WHERE pf.apid = ap.apid 
							     AND pf.ativo = 1 
							     AND pf.local = 1 
							     AND pf.tipo = 2 
							     AND pf.principal = 'S'
							     ORDER BY pf.fotid DESC LIMIT 1), 0) AS thumb
					    	FROM anuncios_pessoas ap
					    	INNER JOIN pessoas p ON p.pesid = ap.pesid					    	
					    	WHERE ap.ativo = 1
					    	AND p.ativo = 1
					    	AND ap.aprovado = 1
					    	AND p.aprovado = 1 
					    	AND EXISTS ((SELECT pfc.fotid
										     FROM pessoas_fotos pfc 
										     WHERE pfc.apid = ap.apid 
										     AND pfc.ativo = 1 
										     AND pfc.local = 1 
										     AND pfc.tipo = 2 
										     AND pfc.principal = 'S')) 
    						{$this->sqlQueryCompl}
    						GROUP BY ad, person, apelido, genero    						
					    	ORDER BY rand()";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Get Query All Person Ads
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryAllPersonAds($pesid){    	
    	$this->sqlQuery = "SELECT
    							ap.apid,
						    	ap.titulo,
						    	ap.descricao,
						    	ap.url AS ad,
						    	ap.visitascount,
						    	CASE WHEN (ap.aprovado = 1) THEN
						    		DATE_FORMAT(ap.cadastro, 'Publicado em %d/%m/%Y as %H:%i:%s')
						    	WHEN (ap.aprovado = 2) THEN
						    		'<strong>REPROVADO!</strong>'
						    	ELSE
						    		'<strong>PENDENTE DE APROVA&Ccedil;&Atilde;O!</strong>'
						    	END AS publicacao,
						    	p.url AS person,
						    	IFNULL((SELECT pf.imagemurl AS thumb
						    	FROM pessoas_fotos pf
						    	WHERE pf.apid = ap.apid
						    	AND pf.local = 1
						    	AND pf.tipo = 2
						    	AND pf.principal = 'S'
						    	ORDER BY pf.fotid DESC LIMIT 1), '../no-portrait.jpg') AS thumb    	
					    	FROM anuncios_pessoas ap
					    	INNER JOIN pessoas p ON p.pesid = ap.pesid
					    	WHERE p.pesid = {$pesid}
    						ORDER BY ap.visitascount DESC, ap.aprovado DESC, ap.cadastro DESC";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Get Query All Person Photos
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryAllPersonPhotos($pesid){
    	$this->sqlQuery = "SELECT
					    		pf.fotid
					    	FROM pessoas_fotos pf
					    	INNER JOIN anuncios_pessoas ap ON ap.apid = pf.apid
					    	INNER JOIN pessoas p ON p.pesid = ap.pesid
					    	WHERE p.pesid = {$pesid}";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
   /**
	* Get Query Person Ad
	*	
	* @author    Daniel Triboni
	* @return	 array
	*/
	public function fQueryAdPerson($person, $ad){
		$this->sqlQueryCompl = ($_SESSION['sPersonLogged'] == true && $_SESSION['sPersonUrl'] == $person ? "" : " AND p.aprovado = 1 AND ap.aprovado = 1 ");
    	$this->sqlQuery = "SELECT
								ap.*,
								p.*,
								p.url AS person,
								ap.url AS ad,
							IFNULL((SELECT pf.imagemurl AS thumb 
							     FROM pessoas_fotos pf 
							     WHERE pf.apid = ap.apid 
							     AND pf.ativo = 1 
							     AND pf.local = 1 
							     AND pf.tipo = 2 
							     AND pf.principal = 'S'
							     ORDER BY pf.fotid DESC LIMIT 1), '../no-portrait.jpg') AS thumb,			    				
							IFNULL((SELECT pfc.imagemurl AS cover 
							     FROM pessoas_fotos pfc 
							     WHERE pfc.apid = ap.apid 
							     AND pfc.ativo = 1 
							     AND pfc.local = 4 
							     AND pfc.tipo = 2 
							     AND pfc.principal = 'S'
							     ORDER BY pfc.fotid DESC LIMIT 1), '../no-cover.jpg') AS cover
							FROM anuncios_pessoas ap
							INNER JOIN pessoas p ON p.pesid = ap.pesid							
							WHERE ap.ativo = 1
							AND p.ativo = 1  			    						    		
							{$this->sqlQueryCompl}							
							AND ap.url = '{$ad}'
							AND p.url = '{$person}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;	
    }
    
    
    /**
     * Get Query Person Register
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryPersonRegister($person){
    	$this->sqlQuery = "SELECT
					    		p.*,
					    		DATE_FORMAT(p.nascimento, '%d/%m/%Y') AS nascimento,					    		
					    		CASE WHEN p.aprovado = 1 THEN
					    			'<i class=\"fa fa-check\"></i> PERFIL APROVADO!'
					    		WHEN p.aprovado = 2 THEN
					    			'<i class=\"fa fa-remove\"></i> PERFIL REPROVADO!'
					    		ELSE
					    			'<i class=\"fa fa-warning\"></i> PERFIL EM FASE DE APROVA&Ccedil;&Atilde;O!'
					    		END AS status,
					    		CASE WHEN p.aprovado = 2 THEN
					    			p.mensagem
					    		ELSE
					    			''
					    		END AS mensagem					    		
					    	FROM pessoas p    	
					    	WHERE p.url = '{$person}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Get Query Ad Title
     *
     * @author    Daniel Triboni
     * @return	 boolean
     */
    public function fQueryPersonAdTitle($title, $apid){
    	$this->sqlQueryCompl = (!is_null($apid) ? " AND ap.apid <> {$apid}" : "");
    	$this->sqlQuery = "SELECT
					    		ap.titulo
					    	FROM anuncios_pessoas ap
					    	WHERE ap.titulo = '{$title}'
					    	{$this->sqlQueryCompl} 
    						AND ap.pesid = ".$_SESSION['sPersonID'];    	
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return (count($this->retRecords) == 0 ? true : false);
    }
    
    
    /**
     * Get Query Person AKA
     *
     * @author    Daniel Triboni
     * @return	 boolean
     */
    public function fQueryPersonAka($aka){
    	$this->sqlQuery = "SELECT
					    		p.apelido
					    	FROM pessoas p
					    	WHERE p.apelido = '{$aka}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return (count($this->retRecords) == 0 ? true : false);
    }
    
    
    /**
     * Get Query Person Email
     *
     * @author    Daniel Triboni
     * @return	 boolean
     */
    public function fQueryPersonEmail($email){
    	$this->sqlQuery = "SELECT
					    		p.email
					    	FROM pessoas p
					    	WHERE p.email = '{$email}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return (count($this->retRecords) == 0 ? true : false);
    }
    
    
    /**
     * Get Query Person Email
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryRetrievePassword($email){
    	$this->sqlQuery = "SELECT
						    		p.*
						    	FROM pessoas p
						    	WHERE p.email = '{$email}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Get Query Person Ad
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryEditPersonAd($person, $ad){
    	$this->sqlQuery = "SELECT
								ap.*
							FROM anuncios_pessoas ap							
							INNER JOIN pessoas p ON p.pesid = ap.pesid
							WHERE ap.url = '{$ad}'
							AND p.url = '{$person}'";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Get Query Person Modalities
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryPersonModalities($apid){
    	if (!empty($apid))
    	{
	    	$this->sqlQuery = "SELECT
						    		mp.modid
						    	FROM modalidades_pessoas mp					    	
						    	WHERE mp.apid = {$apid}";
	    	$this->fExecuteSql($this->sqlQuery);
	    	$this->retRecords = $this->fShowRecords();
	    	return $this->retRecords;
    	}
    }
    
    
    /**
     * Get Query Person Cache
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryPersonCache($apid){
    	if (!empty($apid))
    	{
    		$this->sqlQuery = "SELECT
					    			pc.*
					    		FROM pessoas_cache pc
					    		WHERE pc.apid = {$apid}";
    		$this->fExecuteSql($this->sqlQuery);
    		$this->retRecords = $this->fShowRecords();
    		return $this->retRecords;
    	}
    }
    
    
    /**
     * Update Counter Ad Visits
     *
     * @author   Daniel Triboni
     * @return	 boolean
     */
    public function fQueryUpdateVisitCount($apid){    	
	    $this->sqlQuery = "UPDATE anuncios_pessoas SET visitascount = visitascount + 1 WHERE apid = {$apid}";
	    $this->fExecuteSql($this->sqlQuery);    	
    	return true;
    }
    
    
    /**
     * Query Person Locations
     *
     * @author    Daniel Triboni
     * max latutude and min longitude
     * @return	 array
     */
    public function fQueryPersonLocations($pesid){
    	$this->sqlQuery = "SELECT
						    	lp.*,
						    	(SELECT 
						    		MAX(lp1.latitude) 
						    	FROM locais_pessoas lp1 
						    	WHERE lp1.pesid = p.pesid 
						    	AND lp1.ativo = 1 
						    	AND lp1.show = 0 
						    	HAVING COUNT(lp1.locid) = 1) AS max_latitude,						    	
						    	(SELECT 
						    		MIN(lp2.longitude) 
						    	FROM locais_pessoas lp2 
						    	WHERE lp2.pesid = p.pesid 
						    	AND lp2.ativo = 1 
						    	AND lp2.show = 0 
						    	HAVING COUNT(lp2.locid) = 1) AS min_longitude						    							    	
					    	FROM locais_pessoas lp
					    	INNER JOIN pessoas p ON p.pesid = lp.pesid					    	
					    	WHERE lp.ativo = 1
					    	AND lp.ativo = 1
					    	AND p.pesid = {$pesid}
    						ORDER BY lp.show ASC";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Show person photos except cover photo
     *
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryCurrentPersonPhotos($apid){
    	$this->sqlQuery = "SELECT
    						pf.hash,
    						IFNULL((SELECT pft.titulo AS titulo
							     FROM pessoas_fotos pft 
							     WHERE pft.hash = pf.hash 
							     AND pft.ativo = 1 
							     AND pft.local = 2 
							     AND pft.tipo = 2 
							     AND pft.principal = 'S'), '') AS titulo,
							IFNULL((SELECT pft.descricao AS descricao
							     FROM pessoas_fotos pft 
							     WHERE pft.hash = pf.hash 
							     AND pft.ativo = 1 
							     AND pft.local = 2 
							     AND pft.tipo = 2 
							     AND pft.principal = 'S'), '') AS descricao,	
							IFNULL((SELECT pft.imagemurl AS thumb 
							     FROM pessoas_fotos pft 
							     WHERE pft.hash = pf.hash 
							     AND pft.ativo = 1 
							     AND pft.local = 2 
							     AND pft.tipo = 2 
							     AND pft.principal = 'S'), 'no-thumb.jpg') AS thumb,
					    	IFNULL((SELECT pfl.imagemurl AS large 
							     FROM pessoas_fotos pfl 
							     WHERE pfl.hash = pf.hash 
							     AND pfl.ativo = 1 
							     AND pfl.local = 2 
							     AND pfl.tipo = 1 
							     AND pfl.principal = 'S'), 'no-large.jpg') AS large
					    	FROM pessoas_fotos pf
					    	WHERE pf.ativo = 1
					    	AND pf.apid = {$apid}
					    	AND pf.local NOT IN (1,4)
					    	GROUP BY pf.hash
    						ORDER BY pf.fotid ASC";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Query Current Person Modalities
     *
     * @param  integer $apid
     * @author    Daniel Triboni
     * @return	 array
     */
    public function fQueryCurrentPersonModalities($apid){
    	$this->sqlQuery = "SELECT
    						UPPER(m.modalidade) AS modalidade, m.descricao, m.tipo							    	
				    	FROM modalidades_pessoas mp
				    	INNER JOIN modalidades m ON m.modid = mp.modid				    	
				    	WHERE mp.ativo = 1
				    	AND m.ativo = 1				    					    
				    	AND mp.apid = {$apid}
				    	GROUP BY m.modalidade
				    	ORDER BY 1 ASC";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	return $this->retRecords;
    }
    
    
    /**
     * Query Combo Modalities
     * @param array $arrModalities
     * @return string|NULL
     */
    public function fQueryComboModalities($arrModalities){
    	$modalities = array();
    	$this->sqlQuery = "SELECT mo.modid,
			    				   mo.modalidade,
    							   mo.descricao,
			    				   mo.ativo
    						FROM modalidades mo
					    	WHERE mo.ativo = 1		    	
					    	ORDER BY mo.modalidade ASC";
    	$this->fExecuteSql($this->sqlQuery);
    	$this->retRecords = $this->fShowRecords();
    	$this->retHTML = null;    	
    	
    	if (is_array($arrModalities))
    	{
    		foreach ($arrModalities as $sanity => $modality)
    			$modalities[] = $modality['modid'];
    	}
    	
    	for ($x = 0; $x < count($this->retRecords); $x++)
    	{
    		$this->retHTML .= '<option value="'.$this->retRecords[$x]['modid'].'" '.(in_array($this->retRecords[$x]['modid'], $modalities) ? 'selected' : '').'>'.$this->retRecords[$x]['modalidade'].'</option>';
    	}    		
    	
    	return $this->retHTML;
    }
    
    
    /**
	* Trazer Usuarios
	*	
	* @author    Daniel Triboni
	* @return	 vetor
	*/
	public function fQueryUsers(){
    	$sql = "SELECT
    				u.usuid,
    				u.nome,
    				u.mail
    			FROM usuarios u
    			WHERE u.ativo = 1 ";
    			if($_SESSION['sUserProfile'] == 5){   
    				$sql.= "AND u.usuid = ".$_SESSION['sUserID'];
    			}  
    	$sql.=" ORDER BY u.nome ASC";
    	$this->fExecuteSql($sql);
    	$ret = $this->fShowRecords();
    	return $ret;	
    }
	    
    
	/**
	* Gravar LOG no Sistema
	*
	* @author    Daniel Triboni
	* @param	 integer ID OPERADOR
	* @param	 integer ID CLIENTE
	* @param	 string Acao
	* @return    boolean
	*/	
	private function fRecordLOG($usu_id, $cli_id, $acao){
		$sqlX = "INSERT INTO tbllog (usu_id, cli_id, log_acao)
			     VALUES (".$usu_id.", ".$cli_id.", '".$acao."')";
		$this->fExecuteSql($sqlX);																		
		return true;
	}
    
   
	/**
	 * Query Save Photo
	 * @param object $_REQUEST
	 */
    public function fQuerySavePhoto($obj){
    	//if ($obj['local'] == 1 || $obj['local'] == 4)
    	//	$this->fQueryRemoveCoverAndMainPhotos($obj['apid'], $obj['local']);
    	
    	$sql = "INSERT INTO pessoas_fotos (apid, tipo, imagemurl, local, hash)
       			VALUES ({$obj['apid']}, {$obj['tipo']}, '{$obj['imagemurl']}', {$obj['local']}, '{$obj['hash']}')";
    	$this->fExecuteSql($sql); 
    	
    	$this->fQuerySetAdToDisabled($obj['apid']);
    	return true;
    }
    
    
    /**
     * Query Set AD To Unapproved
     * @param unknown $apid
     * @return boolean
     */
    private function fQuerySetAdToDisabled($apid){
    	$sql = "UPDATE anuncios_pessoas SET aprovado = 0 WHERE apid = {$apid}";
    	$this->fExecuteSql($sql);
    	return true;
    }
      
    
    /**
     * Query Remove Photos by User Defined Locals
     * @param unknown $apid
     * @param unknown $local
     * @return boolean
     */
    private function fQueryRemoveCoverAndMainPhotos($apid, $local){
    	$sql = "DELETE FROM pessoas_fotos WHERE apid = {$apid} AND local = {$local}";
    	$this->fExecuteSql($sql);
    	return true;
    }               
}